document.addEventListener('DOMContentLoaded', async function() {
  	var closeButton = document.getElementById('acceptButton');
	closeButton.addEventListener('click', async function()  {
			window.close();
	});
 
});

